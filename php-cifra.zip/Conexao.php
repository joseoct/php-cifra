<?php

class Conexao {
  private static $instancia;

  public static function get() {
    try {
      if(!isset(self::$instancia))

<<<<<<< HEAD
        // self::$instancia = new PDO("pgsql:host=localhost;port=5432;dbname=php-cifra;user=postgres;password=docker");
      
        self::$instancia = new PDO("mysql:host=localhost;dbname=t1-web;user=root;password=");
        
=======
        self::$instancia = new PDO("pgsql:host=localhost;port=5432;dbname=web-servidor-5;user=postgres;password=docker");

        // self::$instancia = new PDO("mysql:host=localhost;dbname=t1-web;user=root;password=");
                
>>>>>>> 777db91693853011ee2096ca95bb5f38ca7654e4
      return self::$instancia;

    } catch(Exception $e) {

      throw new Exception($e->getMessage());
      
    }
  }
  
}

?>
