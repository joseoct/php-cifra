<h1>Você está logado.</h1>


<form method="POST" action="index.php?acao=logout">
  <input type="submit" value="Logout" class="entrar-input">
</form>

<a href="index.php?acao=cadastrar-cifra">Cadastrar cifra</a>