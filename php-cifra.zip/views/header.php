<!DOCTYPE html>
<html>

<head>
    <title>Cifras dos idiotas</title>
    <link rel="stylesheet" href="assets/styles.css" />
    <link rel="stylesheet" href="assets/bootstrap.css" />
    <link rel="stylesheet" href="assets/all.css" />
</head>

<body>
    